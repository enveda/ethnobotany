# Figures
## Each figure here is plotted and exported here by one of the Jupyter notebooks.
## Note that the figuring ordering might be switched by one since different journals require to move the methods section to the bottom of the manuscript
